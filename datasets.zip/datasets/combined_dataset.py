"""
Combined Dataset for Marine Debris Detection

Combines MARIDA, FloatingObjects, and RefinedFloatingObjects datasets
for comprehensive training of debris detection models.
"""

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, ConcatDataset, WeightedRandomSampler
from pathlib import Path
import random

from .marida_dataset import MARIDADataset
from .floating_objects_dataset import FloatingObjectsDataset


class CombinedDataset(Dataset):
    """
    Combined dataset that samples from multiple debris datasets.
    
    Handles class imbalance and dataset size differences through
    weighted sampling and oversampling strategies.
    
    Args:
        datasets: List of dataset instances
        weights: Sampling weights for each dataset
        mode: 'train', 'val', or 'test'
    """
    
    def __init__(self, datasets, weights=None, mode='train'):
        self.datasets = datasets
        self.mode = mode
        
        # Build unified index
        self.indices = []
        for ds_idx, ds in enumerate(datasets):
            for sample_idx in range(len(ds)):
                self.indices.append((ds_idx, sample_idx))
        
        # Compute sample weights for balanced sampling
        if weights is None:
            # Equal weight per dataset (inversely proportional to size)
            total_samples = sum(len(ds) for ds in datasets)
            weights = [total_samples / len(ds) for ds in datasets]
        
        self.sample_weights = []
        for ds_idx, _ in self.indices:
            self.sample_weights.append(weights[ds_idx])
        
        print(f"CombinedDataset: {len(self.indices)} total samples from {len(datasets)} datasets")
    
    def __len__(self):
        return len(self.indices)
    
    def __getitem__(self, idx):
        ds_idx, sample_idx = self.indices[idx]
        sample = self.datasets[ds_idx][sample_idx]
        sample['dataset_idx'] = ds_idx
        return sample
    
    def get_sampler(self):
        """Get weighted random sampler for balanced training."""
        return WeightedRandomSampler(
            weights=self.sample_weights,
            num_samples=len(self.sample_weights),
            replacement=True
        )


def create_combined_dataloaders(
    marida_root=None,
    marida_splits=None,
    floating_root=None,
    refined_root=None,
    batch_size=8,
    num_workers=4,
    patch_size=256,
    binary=True,
    add_indices=False,
    balanced_sampling=True
):
    """
    Create combined dataloaders from all available datasets.
    
    Args:
        marida_root: Path to MARIDA/patches
        marida_splits: Path to MARIDA/splits
        floating_root: Path to floatingobjects
        refined_root: Path to refinedfloatingobjects
        batch_size: Batch size
        num_workers: Number of workers
        patch_size: Patch size
        binary: Binary classification mode
        add_indices: Add spectral indices
        balanced_sampling: Use balanced sampling across datasets
    
    Returns:
        train_loader, val_loader, test_loader
    """
    train_datasets = []
    val_datasets = []
    test_datasets = []
    
    # Add MARIDA
    if marida_root and Path(marida_root).exists():
        print("Loading MARIDA dataset...")
        
        train_ds = MARIDADataset(
            data_root=marida_root,
            split_file=Path(marida_splits) / 'train_X.txt' if marida_splits else None,
            mode='train',
            binary=binary,
            patch_size=patch_size,
            add_indices=add_indices
        )
        train_datasets.append(train_ds)
        
        val_ds = MARIDADataset(
            data_root=marida_root,
            split_file=Path(marida_splits) / 'val_X.txt' if marida_splits else None,
            mode='val',
            binary=binary,
            patch_size=patch_size,
            add_indices=add_indices
        )
        val_datasets.append(val_ds)
        
        test_ds = MARIDADataset(
            data_root=marida_root,
            split_file=Path(marida_splits) / 'test_X.txt' if marida_splits else None,
            mode='test',
            binary=binary,
            patch_size=patch_size,
            add_indices=add_indices
        )
        test_datasets.append(test_ds)
    
    # Add FloatingObjects
    if floating_root and Path(floating_root).exists():
        print("Loading FloatingObjects dataset...")
        
        floating_train = FloatingObjectsDataset(
            floating_root,
            dataset_type='floating',
            mode='train',
            patch_size=patch_size,
            min_debris_ratio=0.01,  # At least 1% debris for training
            add_indices=add_indices
        )
        train_datasets.append(floating_train)
        
        floating_val = FloatingObjectsDataset(
            floating_root,
            dataset_type='floating',
            mode='val',
            patch_size=patch_size,
            add_indices=add_indices
        )
        val_datasets.append(floating_val)
    
    # Add RefinedFloatingObjects
    if refined_root and Path(refined_root).exists():
        print("Loading RefinedFloatingObjects dataset...")
        
        refined_train = FloatingObjectsDataset(
            refined_root,
            dataset_type='refined',
            mode='train',
            patch_size=patch_size,
            min_debris_ratio=0.01,
            add_indices=add_indices
        )
        train_datasets.append(refined_train)
        
        refined_val = FloatingObjectsDataset(
            refined_root,
            dataset_type='refined',
            mode='val',
            patch_size=patch_size,
            add_indices=add_indices
        )
        val_datasets.append(refined_val)
    
    # Create combined datasets
    if len(train_datasets) == 0:
        raise ValueError("No datasets found! Check paths.")
    
    combined_train = CombinedDataset(train_datasets, mode='train')
    combined_val = CombinedDataset(val_datasets, mode='val') if val_datasets else None
    combined_test = CombinedDataset(test_datasets, mode='test') if test_datasets else None
    
    # Create dataloaders
    if balanced_sampling:
        train_sampler = combined_train.get_sampler()
        train_loader = DataLoader(
            combined_train,
            batch_size=batch_size,
            sampler=train_sampler,
            num_workers=num_workers,
            pin_memory=True,
            drop_last=True
        )
    else:
        train_loader = DataLoader(
            combined_train,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            pin_memory=True,
            drop_last=True
        )
    
    val_loader = DataLoader(
        combined_val,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    ) if combined_val else None
    
    test_loader = DataLoader(
        combined_test,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    ) if combined_test else None
    
    return train_loader, val_loader, test_loader


def get_class_weights(dataloader, num_classes=2):
    """
    Calculate class weights for handling class imbalance.
    
    Args:
        dataloader: DataLoader to compute weights from
        num_classes: Number of classes
    
    Returns:
        Tensor of class weights
    """
    class_counts = torch.zeros(num_classes)
    
    for batch in dataloader:
        labels = batch['label']
        for c in range(num_classes):
            class_counts[c] += (labels == c).sum()
    
    # Inverse frequency weighting
    total = class_counts.sum()
    weights = total / (num_classes * class_counts + 1e-6)
    
    # Normalize
    weights = weights / weights.sum() * num_classes
    
    return weights
