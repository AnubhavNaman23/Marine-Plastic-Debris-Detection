"""
Generate Synthetic Training Data for Marine Debris Classification

Since the original CSV files require Git LFS (which is disabled for the repo),
this script generates synthetic training data based on the paper's specifications.

The data follows the spectral signatures of:
- Water (class 1)
- Plastic (class 2)  
- Driftwood (class 3)
- Seaweed (class 4)
- Pumice (class 5)
- Sea Snot (class 6)
- Sea Foam (class 7)

Reference: Duarte & Azevedo (2023) - Automatic Detection and Identification 
of Floating Marine Debris Using Multispectral Satellite Imagery
"""

import numpy as np
import pandas as pd
from pathlib import Path

# Sentinel-2 band names (excluding B9, B10)
BANDS = ['B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B8A', 'B11', 'B12']

# Class names
CLASSES = {
    1: 'Water',
    2: 'Plastic',
    3: 'Driftwood', 
    4: 'Seaweed',
    5: 'Pumice',
    6: 'Sea Snot',
    7: 'Sea Foam'
}

# Approximate spectral signatures (reflectance values scaled 0-10000)
# Based on literature values for Sentinel-2
SPECTRAL_SIGNATURES = {
    # Water: Low reflectance, decreasing with wavelength
    1: {
        'B1': (400, 100), 'B2': (350, 80), 'B3': (250, 70), 'B4': (150, 50),
        'B5': (100, 40), 'B6': (80, 30), 'B7': (60, 25), 'B8': (50, 20),
        'B8A': (40, 15), 'B11': (20, 10), 'B12': (15, 8)
    },
    # Plastic: Higher NIR reflectance (FDI positive)
    2: {
        'B1': (600, 150), 'B2': (800, 200), 'B3': (1200, 300), 'B4': (1500, 350),
        'B5': (2000, 400), 'B6': (2200, 450), 'B7': (2400, 500), 'B8': (2800, 550),
        'B8A': (2600, 500), 'B11': (1800, 400), 'B12': (1200, 300)
    },
    # Driftwood: Similar to plastic but different NIR/SWIR ratio
    3: {
        'B1': (500, 120), 'B2': (700, 180), 'B3': (1000, 250), 'B4': (1300, 300),
        'B5': (1800, 380), 'B6': (2000, 420), 'B7': (2200, 460), 'B8': (2500, 500),
        'B8A': (2400, 480), 'B11': (2200, 450), 'B12': (1800, 380)
    },
    # Seaweed/Vegetation: High NDVI (NIR >> Red)
    4: {
        'B1': (300, 80), 'B2': (400, 100), 'B3': (600, 150), 'B4': (500, 120),
        'B5': (1500, 350), 'B6': (2500, 500), 'B7': (3000, 600), 'B8': (3500, 700),
        'B8A': (3300, 650), 'B11': (1500, 350), 'B12': (800, 200)
    },
    # Pumice: Volcanic, bright across all bands
    5: {
        'B1': (1500, 300), 'B2': (2000, 400), 'B3': (2500, 500), 'B4': (2800, 550),
        'B5': (3000, 600), 'B6': (3200, 640), 'B7': (3400, 680), 'B8': (3600, 700),
        'B8A': (3500, 690), 'B11': (3000, 600), 'B12': (2500, 500)
    },
    # Sea Snot (Marine Mucilage): Organic, moderate reflectance
    6: {
        'B1': (450, 110), 'B2': (600, 150), 'B3': (900, 220), 'B4': (1100, 270),
        'B5': (1600, 350), 'B6': (1900, 400), 'B7': (2100, 440), 'B8': (2300, 480),
        'B8A': (2200, 460), 'B11': (1600, 350), 'B12': (1100, 270)
    },
    # Sea Foam: Bright, especially in visible
    7: {
        'B1': (2000, 400), 'B2': (2500, 500), 'B3': (3000, 600), 'B4': (3200, 640),
        'B5': (3000, 600), 'B6': (2800, 560), 'B7': (2600, 520), 'B8': (2400, 480),
        'B8A': (2300, 460), 'B11': (1500, 300), 'B12': (1000, 200)
    }
}


def generate_samples(class_id, n_samples, sentinel_2='A'):
    """Generate synthetic samples for a given class."""
    data = []
    signature = SPECTRAL_SIGNATURES[class_id]
    
    for _ in range(n_samples):
        sample = {}
        for band in BANDS:
            mean, std = signature[band]
            # Add some noise and ensure positive values
            value = max(0, np.random.normal(mean, std))
            sample[band] = value
        
        sample['Sentinel-2'] = sentinel_2
        sample['label'] = class_id
        data.append(sample)
    
    return data


def generate_dataset(samples_per_class=1000, balanced=True):
    """Generate complete synthetic dataset."""
    all_data = []
    
    for class_id in CLASSES.keys():
        # Vary samples per class if not balanced
        if balanced:
            n_samples = samples_per_class
        else:
            # Water is most common, plastic is rare
            weights = {1: 5.0, 2: 0.5, 3: 0.3, 4: 1.0, 5: 0.2, 6: 0.3, 7: 0.5}
            n_samples = int(samples_per_class * weights[class_id])
        
        # Mix of Sentinel-2A and 2B
        n_s2a = int(n_samples * 0.6)
        n_s2b = n_samples - n_s2a
        
        all_data.extend(generate_samples(class_id, n_s2a, 'A'))
        all_data.extend(generate_samples(class_id, n_s2b, 'B'))
    
    df = pd.DataFrame(all_data)
    
    # Shuffle
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    return df


def main():
    output_dir = Path(__file__).parent / 'csv_data'
    output_dir.mkdir(exist_ok=True)
    
    print("Generating Synthetic Marine Debris Dataset")
    print("=" * 50)
    
    # Generate balanced dataset
    print("\n1. Generating balanced dataset (1000 samples/class)...")
    balanced_df = generate_dataset(samples_per_class=1000, balanced=True)
    balanced_df.to_csv(output_dir / 'balanced_data.csv', index=False)
    print(f"   Saved: {len(balanced_df)} samples")
    
    # Generate imbalanced dataset (more realistic)
    print("\n2. Generating realistic imbalanced dataset...")
    all_df = generate_dataset(samples_per_class=2000, balanced=False)
    all_df.to_csv(output_dir / 'all_data.csv', index=False)
    print(f"   Saved: {len(all_df)} samples")
    
    # Split into train/test
    print("\n3. Creating train/test split (80/20)...")
    train_size = int(len(balanced_df) * 0.8)
    train_df = balanced_df.iloc[:train_size]
    test_df = balanced_df.iloc[train_size:]
    
    train_df.to_csv(output_dir / 'train.csv', index=False)
    test_df.to_csv(output_dir / 'test.csv', index=False)
    print(f"   Train: {len(train_df)} samples")
    print(f"   Test:  {len(test_df)} samples")
    
    # Print class distribution
    print("\n4. Class Distribution (balanced):")
    for class_id, class_name in CLASSES.items():
        count = len(balanced_df[balanced_df['label'] == class_id])
        print(f"   {class_id}. {class_name}: {count}")
    
    print("\n" + "=" * 50)
    print("Dataset generation complete!")
    print(f"Files saved to: {output_dir}")
    print("\nColumns:", list(balanced_df.columns))


if __name__ == "__main__":
    main()
