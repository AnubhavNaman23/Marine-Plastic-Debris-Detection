"""
Floating Marine Debris CSV Dataset Loader

Loads the CSV pixel-level spectral data from:
https://github.com/miguelmendesduarte/Floating-Marine-Debris-Data

Classes:
    1: Water
    2: Plastic
    3: Driftwood
    4: Seaweed
    5: Pumice
    6: Sea Snot
    7: Sea Foam

Features: 11 spectral bands (B1-B8, B8A, B11, B12) + spectral indices
"""

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')


# Class labels
CLASS_NAMES = {
    1: 'Water',
    2: 'Plastic',
    3: 'Driftwood',
    4: 'Seaweed',
    5: 'Pumice',
    6: 'Sea Snot',
    7: 'Sea Foam'
}

# Spectral band columns (11 bands - B9, B10 excluded due to low atmospheric transmittance)
BAND_COLUMNS = ['B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B8A', 'B11', 'B12']


def add_spectral_indices(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add all spectral indices from the original research paper.
    
    These indices help distinguish between different floating materials.
    """
    df = df.copy()
    
    # Plastic Index (PI) - key for plastic detection
    df["PI"] = df["B8"] / (df["B8"] + df["B4"] + 1e-8)
    
    # Normalised Difference Water Index (NDWI)
    df["NDWI"] = (df["B3"] - df["B8"]) / (df["B8"] + df["B3"] + 1e-8)
    
    # Water Ratio Index (WRI)
    df["WRI"] = (df["B3"] + df["B4"]) / (df["B8"] + df["B12"] + 1e-8)
    
    # Automated Water Extraction Index (AWEI)
    df["AWEI"] = 4 * (df["B3"] + df["B12"]) - (0.25 * df["B8"] + 2.75 * df["B11"])
    
    # Modified Normalization Difference Water Index (MNDWI)
    df["MNDWI"] = (df["B3"] - df["B12"]) / (df["B4"] + df["B12"] + 1e-8)
    
    # Simple Ratio (SR)
    df["SR"] = df["B8"] / (df["B4"] + 1e-8)
    
    # Reversed Normalised Difference Vegetation Index (RNDVI)
    df["RNDVI"] = (df["B4"] - df["B8"]) / (df["B4"] + df["B8"] + 1e-8)
    
    # Anthocyanin Reflectance Index (ARI)
    df["ARI"] = (1 / (df["B3"] + 1e-8)) - (1 / (df["B5"] + 1e-8))
    
    # Modified Anthocyanin Reflectance Index (MARI)
    df["MARI"] = ((1 / (df["B3"] + 1e-8)) - (1 / (df["B5"] + 1e-8))) * df["B7"]
    
    # Chlorophyll Red-Edge (CHL_RedEdge)
    df["CHL_RedEdge"] = df["B8"] / (df["B5"] + 1e-8) - 1
    
    # Red Edge Position Index (REPI)
    df["REPI"] = 700 + 40 * (((df["B4"] + df["B7"]) / 2) - df["B5"]) / (df["B6"] - df["B5"] + 1e-8)
    
    # Enhanced Vegetation Index (EVI)
    df["EVI"] = 2.5 * (df["B8"] - df["B4"]) / (df["B8"] + 6 * df["B4"] - 7.5 * df["B2"] + 1 + 1e-8)
    
    # Enhanced Vegetation Index 2 (EVI2)
    df["EVI2"] = 2.4 * (df["B8"] - df["B4"]) / (df["B8"] + df["B4"] + 1 + 1e-8)
    
    # Green Normalised Difference Vegetation Index (GNDVI)
    df["GNDVI"] = (df["B8"] - df["B3"]) / (df["B3"] + df["B8"] + 1e-8)
    
    # Modified Chlorophyll Absorption in Reflectance Index (MCARI)
    df["MCARI"] = (df["B5"] - df["B4"]) - 0.2 * (df["B5"] - df["B3"]) * (df["B5"] / (df["B4"] + 1e-8))
    
    # Moisture Index (MSI)
    df["MSI"] = df["B11"] / (df["B8"] + 1e-8)
    
    # Normalised Difference Moisture Index (NDMI)
    df["NDMI"] = (df["B8"] - df["B11"]) / (df["B8"] + df["B11"] + 1e-8)
    
    # Normalized Burn Ratio (NBR)
    df["NBR"] = (df["B8"] - df["B12"]) / (df["B8"] + df["B12"] + 1e-8)
    
    # Normalised Difference Snow Index (NDSI)
    df["NDSI"] = (df["B3"] - df["B11"]) / (df["B3"] + df["B11"] + 1e-8)
    
    # Soil Adjusted Vegetation Index (SAVI)
    df["SAVI"] = ((df["B8"] - df["B4"]) / (df["B8"] + df["B4"] + 0.5 + 1e-8)) * 1.5
    
    # Oil Spill Index (OSI)
    df["OSI"] = (df["B3"] + df["B4"]) / (df["B2"] + 1e-8)
    
    # Pan Normalised Difference Vegetation Index (PNDVI)
    df["PNDVI"] = (df["B8"] - (df["B2"] + df["B3"] + df["B4"])) / (df["B8"] + (df["B2"] + df["B3"] + df["B4"]) + 1e-8)
    
    # Normalised Difference Vegetation Index (NDVI)
    df["NDVI"] = (df["B8"] - df["B4"]) / (df["B8"] + df["B4"] + 1e-8)
    
    # Floating Debris Index (FDI) - assuming Sentinel-2A
    df["FDI"] = df["B8"] - (df["B6"] + (df["B11"] - df["B6"]) * ((833 - 665) / (1610.4 - 665)) * 10)
    
    # Replace inf values
    df = df.replace([np.inf, -np.inf], 0)
    df = df.fillna(0)
    
    return df


# List of all spectral indices
INDEX_COLUMNS = [
    'PI', 'NDWI', 'WRI', 'AWEI', 'MNDWI', 'SR', 'RNDVI', 'ARI', 'MARI',
    'CHL_RedEdge', 'REPI', 'EVI', 'EVI2', 'GNDVI', 'MCARI', 'MSI', 'NDMI',
    'NBR', 'NDSI', 'SAVI', 'OSI', 'PNDVI', 'NDVI', 'FDI'
]


class FloatingDebrisCSVDataset(Dataset):
    """
    PyTorch Dataset for Floating Marine Debris CSV data.
    
    Args:
        csv_path: Path to CSV file (train.csv, test.csv, all_data.csv, etc.)
        add_indices: Whether to add spectral indices as features
        normalize: Whether to normalize features
        scaler: Pre-fitted scaler (for test/val sets)
        binary_classification: If True, classify as Debris(1) vs Non-Debris(0)
        target_class: For binary, which class is positive (default: 2=Plastic)
    """
    
    def __init__(
        self,
        csv_path,
        add_indices=True,
        normalize=True,
        scaler=None,
        binary_classification=False,
        target_class=2,  # Plastic
        label_column='label'
    ):
        self.csv_path = Path(csv_path)
        self.add_indices = add_indices
        self.normalize = normalize
        self.binary_classification = binary_classification
        self.target_class = target_class
        
        # Load data
        self.df = pd.read_csv(csv_path)
        
        # Check for label column
        if label_column in self.df.columns:
            self.labels = self.df[label_column].values
        elif 'Label' in self.df.columns:
            self.labels = self.df['Label'].values
        else:
            raise ValueError(f"Label column not found. Columns: {self.df.columns.tolist()}")
        
        # Add spectral indices
        if add_indices:
            self.df = add_spectral_indices(self.df)
            self.feature_columns = BAND_COLUMNS + INDEX_COLUMNS
        else:
            self.feature_columns = BAND_COLUMNS
        
        # Get features (only existing columns)
        available_cols = [c for c in self.feature_columns if c in self.df.columns]
        self.features = self.df[available_cols].values.astype(np.float32)
        
        # Normalize
        if normalize:
            if scaler is None:
                self.scaler = StandardScaler()
                self.features = self.scaler.fit_transform(self.features)
            else:
                self.scaler = scaler
                self.features = self.scaler.transform(self.features)
        else:
            self.scaler = None
        
        # Binary classification
        if binary_classification:
            # 1 = target class, 0 = other
            self.labels = (self.labels == target_class).astype(np.int64)
        else:
            # Multi-class: shift labels to 0-indexed
            self.labels = self.labels - 1  # 1-7 -> 0-6
        
        self.n_features = self.features.shape[1]
        self.n_classes = 2 if binary_classification else 7
        
        print(f"Loaded {len(self)} samples with {self.n_features} features")
        print(f"Class distribution: {np.bincount(self.labels)}")
    
    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        features = torch.tensor(self.features[idx], dtype=torch.float32)
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return features, label
    
    def get_class_weights(self):
        """Calculate class weights for handling imbalance."""
        class_counts = np.bincount(self.labels)
        total = len(self.labels)
        weights = total / (len(class_counts) * class_counts + 1e-6)
        return torch.tensor(weights, dtype=torch.float32)


def load_csv_datasets(
    data_dir,
    add_indices=True,
    normalize=True,
    binary_classification=False,
    target_class=2,
    val_split=0.15,
    random_state=42
):
    """
    Load train/val/test datasets from CSV files.
    
    Args:
        data_dir: Directory containing CSV files
        add_indices: Add spectral indices
        normalize: Normalize features
        binary_classification: Binary vs multi-class
        target_class: Target class for binary classification
        val_split: Validation split ratio from training data
        random_state: Random seed
    
    Returns:
        train_dataset, val_dataset, test_dataset, scaler
    """
    data_dir = Path(data_dir)
    
    # Check for existing train/test split files
    train_path = data_dir / 'train.csv'
    test_path = data_dir / 'test.csv'
    all_data_path = data_dir / 'all_data.csv'
    balanced_path = data_dir / 'balanced_data.csv'
    
    if train_path.exists() and test_path.exists():
        print("Using existing train.csv and test.csv")
        
        # Load train data
        train_df = pd.read_csv(train_path)
        test_df = pd.read_csv(test_path)
        
    elif all_data_path.exists():
        print("Using all_data.csv with random split")
        
        all_df = pd.read_csv(all_data_path)
        train_df, test_df = train_test_split(
            all_df, test_size=0.2, random_state=random_state, stratify=all_df['label']
        )
    elif balanced_path.exists():
        print("Using balanced_data.csv with random split")
        
        all_df = pd.read_csv(balanced_path)
        train_df, test_df = train_test_split(
            all_df, test_size=0.2, random_state=random_state, stratify=all_df['label']
        )
    else:
        raise FileNotFoundError(f"No CSV files found in {data_dir}")
    
    # Create validation split from training data
    train_df, val_df = train_test_split(
        train_df, test_size=val_split, random_state=random_state, 
        stratify=train_df['label'] if 'label' in train_df.columns else train_df['Label']
    )
    
    # Save temporary files for dataset loading
    train_temp = data_dir / '_train_temp.csv'
    val_temp = data_dir / '_val_temp.csv'
    test_temp = data_dir / '_test_temp.csv'
    
    train_df.to_csv(train_temp, index=False)
    val_df.to_csv(val_temp, index=False)
    test_df.to_csv(test_temp, index=False)
    
    # Create datasets
    train_dataset = FloatingDebrisCSVDataset(
        train_temp, add_indices=add_indices, normalize=normalize,
        binary_classification=binary_classification, target_class=target_class
    )
    
    val_dataset = FloatingDebrisCSVDataset(
        val_temp, add_indices=add_indices, normalize=normalize,
        scaler=train_dataset.scaler,  # Use same scaler
        binary_classification=binary_classification, target_class=target_class
    )
    
    test_dataset = FloatingDebrisCSVDataset(
        test_temp, add_indices=add_indices, normalize=normalize,
        scaler=train_dataset.scaler,
        binary_classification=binary_classification, target_class=target_class
    )
    
    # Clean up temp files
    train_temp.unlink()
    val_temp.unlink()
    test_temp.unlink()
    
    return train_dataset, val_dataset, test_dataset, train_dataset.scaler


def create_csv_dataloaders(
    data_dir,
    batch_size=64,
    add_indices=True,
    normalize=True,
    binary_classification=False,
    target_class=2,
    num_workers=4
):
    """
    Create DataLoaders for CSV dataset.
    
    Returns:
        train_loader, val_loader, test_loader, n_features, n_classes, class_weights
    """
    train_ds, val_ds, test_ds, scaler = load_csv_datasets(
        data_dir, add_indices, normalize, binary_classification, target_class
    )
    
    train_loader = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=True, drop_last=True
    )
    
    val_loader = DataLoader(
        val_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True
    )
    
    test_loader = DataLoader(
        test_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True
    )
    
    return (
        train_loader, val_loader, test_loader,
        train_ds.n_features, train_ds.n_classes, train_ds.get_class_weights()
    )
