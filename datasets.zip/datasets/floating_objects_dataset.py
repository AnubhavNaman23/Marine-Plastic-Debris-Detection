"""
FloatingObjects & RefinedFloatingObjects Dataset Loader

Combines FloatingObjects dataset (full scenes) and RefinedFloatingObjects (regional TIFs)
for training marine debris detection models.

Datasets include:
- FloatingObjects: Original floating objects dataset with full scenes
- RefinedFloatingObjects: Enhanced annotations for Accra, Durban, Lagos, Venice, NewOrleans, Marmara
"""

import os
import numpy as np
import torch
from torch.utils.data import Dataset
import rasterio
from rasterio.windows import Window
import geopandas as gpd
from pathlib import Path
import albumentations as A
from albumentations.pytorch import ToTensorV2


def get_floating_transforms(mode='train', patch_size=256):
    """Get transforms for FloatingObjects dataset."""
    if mode == 'train':
        return A.Compose([
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.5),
            A.RandomRotate90(p=0.5),
            A.ShiftScaleRotate(
                shift_limit=0.05,
                scale_limit=0.1,
                rotate_limit=30,
                p=0.5
            ),
            A.GaussNoise(var_limit=(0.0, 0.001), p=0.2),
            ToTensorV2(transpose_mask=True),
        ])
    else:
        return A.Compose([
            ToTensorV2(transpose_mask=True),
        ])


def shapefile_to_mask(shapefile_path, reference_tif, burn_value=1):
    """
    Convert shapefile annotations to raster mask.
    
    Args:
        shapefile_path: Path to .shp file with polygon annotations
        reference_tif: Path to reference TIF for CRS and dimensions
        burn_value: Value to burn into mask (1 for debris)
    
    Returns:
        Numpy array mask
    """
    from rasterio.features import rasterize
    
    # Read shapefile
    gdf = gpd.read_file(shapefile_path)
    
    # Get reference image properties
    with rasterio.open(reference_tif) as src:
        out_shape = (src.height, src.width)
        transform = src.transform
        crs = src.crs
    
    # Reproject shapefile if needed
    if gdf.crs != crs:
        gdf = gdf.to_crs(crs)
    
    # Rasterize
    if len(gdf) > 0:
        mask = rasterize(
            [(geom, burn_value) for geom in gdf.geometry],
            out_shape=out_shape,
            transform=transform,
            fill=0,
            dtype=np.uint8
        )
    else:
        mask = np.zeros(out_shape, dtype=np.uint8)
    
    return mask


class FloatingObjectsDataset(Dataset):
    """
    Dataset for FloatingObjects and RefinedFloatingObjects.
    
    Extracts patches from large scenes and corresponding masks/shapefiles.
    
    Args:
        data_root: Path to dataset (floatingobjects or refinedfloatingobjects)
        dataset_type: 'floating' or 'refined'
        mode: 'train', 'val', 'test'
        patch_size: Size of patches to extract
        stride: Stride for patch extraction (default = patch_size for no overlap)
        transform: Optional custom transforms
        min_debris_ratio: Minimum debris ratio to include patch (for training)
        add_indices: Add spectral indices as extra channels
    """
    
    BANDS = ['B01', 'B02', 'B03', 'B04', 'B05', 'B06', 
             'B07', 'B08', 'B8A', 'B09', 'B11', 'B12']
    
    def __init__(
        self,
        data_root,
        dataset_type='floating',
        mode='train',
        patch_size=256,
        stride=None,
        transform=None,
        min_debris_ratio=0.0,
        add_indices=False,
        regions=None  # For refined dataset, specify regions
    ):
        self.data_root = Path(data_root)
        self.dataset_type = dataset_type
        self.mode = mode
        self.patch_size = patch_size
        self.stride = stride if stride else patch_size
        self.min_debris_ratio = min_debris_ratio if mode == 'train' else 0.0
        self.add_indices = add_indices
        
        if transform is not None:
            self.transform = transform
        else:
            self.transform = get_floating_transforms(mode, patch_size)
        
        # Scan and extract patches
        self.patches = []
        
        if dataset_type == 'refined':
            self._load_refined_dataset(regions)
        else:
            self._load_floating_dataset()
        
        print(f"FloatingObjects Dataset ({dataset_type}): Loaded {len(self.patches)} patches for {mode}")
    
    def _load_floating_dataset(self):
        """Load original FloatingObjects dataset."""
        scenes_dir = self.data_root / 'scenes'
        masks_dir = self.data_root / 'masks'
        
        if not scenes_dir.exists():
            print(f"Warning: scenes directory not found at {scenes_dir}")
            return
        
        # Find all scene TIFs
        for scene_file in scenes_dir.glob('*.tif'):
            scene_name = scene_file.stem
            
            # Look for corresponding mask
            mask_file = masks_dir / f"{scene_name}_mask.tif"
            if not mask_file.exists():
                mask_file = masks_dir / f"{scene_name}.tif"
            
            if mask_file.exists():
                self._extract_patches(scene_file, mask_file)
    
    def _load_refined_dataset(self, regions=None):
        """Load RefinedFloatingObjects dataset."""
        # Default regions
        all_regions = ['accra', 'durban', 'lagos', 'venice', 'neworleans', 'marmara']
        regions = regions if regions else all_regions
        
        for region in regions:
            region_dir = self.data_root / region
            if not region_dir.exists():
                continue
            
            # Find TIF files in region
            for tif_file in region_dir.glob('*.tif'):
                # Find corresponding shapefile
                shp_name = tif_file.stem
                shp_file = region_dir / f"{shp_name}.shp"
                
                # Alternative naming patterns
                if not shp_file.exists():
                    shp_file = region_dir / f"{shp_name}_annotations.shp"
                if not shp_file.exists():
                    # Look in shapefiles subdirectory
                    shp_file = region_dir / 'shapefiles' / f"{shp_name}.shp"
                
                if shp_file.exists():
                    # Create mask from shapefile
                    mask = shapefile_to_mask(shp_file, tif_file)
                    self._extract_patches_from_array(tif_file, mask, region)
    
    def _extract_patches(self, scene_file, mask_file):
        """Extract patches from scene and mask files."""
        with rasterio.open(scene_file) as src:
            height, width = src.height, src.width
        
        with rasterio.open(mask_file) as msrc:
            full_mask = msrc.read(1)
        
        # Calculate patch positions
        for y in range(0, height - self.patch_size + 1, self.stride):
            for x in range(0, width - self.patch_size + 1, self.stride):
                # Check debris ratio in this patch
                patch_mask = full_mask[y:y+self.patch_size, x:x+self.patch_size]
                debris_ratio = np.mean(patch_mask > 0)
                
                if debris_ratio >= self.min_debris_ratio:
                    self.patches.append({
                        'scene': str(scene_file),
                        'mask_file': str(mask_file),
                        'x': x,
                        'y': y,
                        'debris_ratio': debris_ratio,
                        'id': f"{scene_file.stem}_{y}_{x}"
                    })
    
    def _extract_patches_from_array(self, scene_file, mask_array, region=''):
        """Extract patches from scene file and precomputed mask array."""
        with rasterio.open(scene_file) as src:
            height, width = src.height, src.width
        
        for y in range(0, height - self.patch_size + 1, self.stride):
            for x in range(0, width - self.patch_size + 1, self.stride):
                patch_mask = mask_array[y:y+self.patch_size, x:x+self.patch_size]
                debris_ratio = np.mean(patch_mask > 0)
                
                if debris_ratio >= self.min_debris_ratio:
                    self.patches.append({
                        'scene': str(scene_file),
                        'mask_array': mask_array,
                        'x': x,
                        'y': y,
                        'debris_ratio': debris_ratio,
                        'id': f"{region}_{scene_file.stem}_{y}_{x}"
                    })
    
    def __len__(self):
        return len(self.patches)
    
    def __getitem__(self, idx):
        patch_info = self.patches[idx]
        
        # Load image patch
        with rasterio.open(patch_info['scene']) as src:
            window = Window(
                patch_info['x'],
                patch_info['y'],
                self.patch_size,
                self.patch_size
            )
            image = src.read(window=window).astype(np.float32)
            
            # Normalize
            image = image / 10000.0
            image = np.clip(image, 0, 1)
        
        # Load mask
        if 'mask_array' in patch_info:
            y, x = patch_info['y'], patch_info['x']
            mask = patch_info['mask_array'][y:y+self.patch_size, x:x+self.patch_size].astype(np.int64)
        else:
            with rasterio.open(patch_info['mask_file']) as msrc:
                window = Window(
                    patch_info['x'],
                    patch_info['y'],
                    self.patch_size,
                    self.patch_size
                )
                mask = msrc.read(1, window=window).astype(np.int64)
        
        # Binary mask (any positive value = debris)
        mask = (mask > 0).astype(np.int64)
        
        # Transpose for albumentations
        image = np.transpose(image, (1, 2, 0))  # (C, H, W) -> (H, W, C)
        
        if self.transform:
            transformed = self.transform(image=image, mask=mask)
            image = transformed['image']
            mask = transformed['mask']
        else:
            image = torch.from_numpy(image.transpose(2, 0, 1))
            mask = torch.from_numpy(mask)
        
        # Add spectral indices
        if self.add_indices:
            from ..utils.spectral_indices import add_indices_to_bands
            image_np = image.numpy()
            image_with_indices = add_indices_to_bands(image_np)
            image = torch.from_numpy(image_with_indices)
        
        return {
            'image': image.float(),
            'label': mask.long(),
            'id': patch_info['id'],
            'debris_ratio': patch_info['debris_ratio']
        }


def create_floating_objects_dataloaders(
    floating_root=None,
    refined_root=None,
    batch_size=8,
    num_workers=4,
    patch_size=256,
    train_split=0.7,
    val_split=0.15,
    add_indices=False
):
    """
    Create dataloaders for FloatingObjects datasets.
    
    Args:
        floating_root: Path to floatingobjects directory
        refined_root: Path to refinedfloatingobjects directory
        batch_size: Batch size
        num_workers: Number of workers
        patch_size: Patch size
        train_split: Training split ratio
        val_split: Validation split ratio
        add_indices: Add spectral indices
    
    Returns:
        train_loader, val_loader, test_loader
    """
    from torch.utils.data import DataLoader, ConcatDataset, Subset
    import random
    
    all_patches = []
    
    # Load floating objects
    if floating_root and Path(floating_root).exists():
        floating_ds = FloatingObjectsDataset(
            floating_root,
            dataset_type='floating',
            mode='train',
            patch_size=patch_size,
            add_indices=add_indices
        )
        all_patches.extend([(floating_ds, i) for i in range(len(floating_ds))])
    
    # Load refined floating objects
    if refined_root and Path(refined_root).exists():
        refined_ds = FloatingObjectsDataset(
            refined_root,
            dataset_type='refined',
            mode='train',
            patch_size=patch_size,
            add_indices=add_indices
        )
        all_patches.extend([(refined_ds, i) for i in range(len(refined_ds))])
    
    # Shuffle and split
    random.shuffle(all_patches)
    n_total = len(all_patches)
    n_train = int(n_total * train_split)
    n_val = int(n_total * val_split)
    
    train_indices = list(range(n_train))
    val_indices = list(range(n_train, n_train + n_val))
    test_indices = list(range(n_train + n_val, n_total))
    
    # Create dataloaders with appropriate transforms
    # For simplicity, we'll use the same dataset but filter by indices
    train_loader = DataLoader(
        Subset(floating_ds if floating_root else refined_ds, train_indices),
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=True
    )
    
    val_loader = DataLoader(
        Subset(floating_ds if floating_root else refined_ds, val_indices),
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    test_loader = DataLoader(
        Subset(floating_ds if floating_root else refined_ds, test_indices),
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader, test_loader
