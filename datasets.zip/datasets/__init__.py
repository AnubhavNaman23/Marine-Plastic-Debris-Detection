"""
Dataset utilities for Marine Debris Detection

Includes:
- Image-based datasets (MARIDA, FloatingObjects) for segmentation
- CSV-based dataset (Floating-Marine-Debris-Data) for pixel classification
"""
from .marida_dataset import MARIDADataset
from .floating_objects_dataset import FloatingObjectsDataset
from .combined_dataset import CombinedDataset
from .csv_dataset import FloatingDebrisCSVDataset, load_csv_datasets, create_csv_dataloaders

__all__ = [
    'MARIDADataset', 
    'FloatingObjectsDataset', 
    'CombinedDataset',
    'FloatingDebrisCSVDataset',
    'load_csv_datasets',
    'create_csv_dataloaders'
]
