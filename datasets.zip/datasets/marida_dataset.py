"""
MARIDA Dataset Loader for Marine Debris Detection

MARIDA (Marine Debris Archive) contains Sentinel-2 patches with multi-class labels:
- Marine Debris, Dense Sargassum, Sparse Sargassum, Natural Organic Material
- Ship, Cloud, Marine Water, Turbid Water, Shallow Water
- Waves, Foam, Sediment-laden Water, Ice, Wakes, Mixed Water

Reference: Kikaki et al. 2022 - "MARIDA: A benchmark for Marine Debris detection from Sentinel-2 remote sensing data"
"""

import os
import numpy as np
import torch
from torch.utils.data import Dataset
import rasterio
from pathlib import Path
import albumentations as A
from albumentations.pytorch import ToTensorV2


# MARIDA class mapping (from labels_mapping.txt)
MARIDA_CLASSES = {
    0: 'Background',        # Added for no-data
    1: 'Marine Debris',
    2: 'Dense Sargassum',
    3: 'Sparse Sargassum',
    4: 'Natural Organic Material',
    5: 'Ship',
    6: 'Clouds',
    7: 'Marine Water',
    8: 'Turbid Water',
    9: 'Shallow Water',
    10: 'Foam',
    11: 'Sediment-Laden Water',
    12: 'Wakes',
    13: 'Mixed Water',
    14: 'Sea snot (Mucilage)',
    15: 'Jellyfish'
}

# Binary mapping: debris (1) vs non-debris (0)
DEBRIS_CLASSES = [1, 2, 3, 4]  # Marine Debris + Sargassum + Organic Material


def get_marida_transforms(mode='train', patch_size=256):
    """
    Get data augmentation transforms for MARIDA dataset.
    
    Args:
        mode: 'train', 'val', or 'test'
        patch_size: Size of patches (default 256)
    
    Returns:
        Albumentations compose object
    """
    if mode == 'train':
        return A.Compose([
            A.RandomCrop(width=patch_size, height=patch_size),
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.5),
            A.RandomRotate90(p=0.5),
            A.ShiftScaleRotate(
                shift_limit=0.1,
                scale_limit=0.2,
                rotate_limit=45,
                p=0.5
            ),
            # Careful with channel-wise transforms on spectral data
            A.GaussNoise(var_limit=(0.0, 0.001), p=0.3),
            ToTensorV2(transpose_mask=True),
        ])
    else:
        return A.Compose([
            A.CenterCrop(width=patch_size, height=patch_size),
            ToTensorV2(transpose_mask=True),
        ])


class MARIDADataset(Dataset):
    """
    PyTorch Dataset for MARIDA (Marine Debris Archive).
    
    Args:
        data_root: Path to MARIDA/patches directory
        split_file: Path to split file (train_X.txt, val_X.txt, test_X.txt)
        bands: List of bands to load (default all 12)
        mode: 'train', 'val', or 'test' (affects augmentations)
        binary: If True, convert to binary classification (debris vs non-debris)
        transform: Optional custom transform
        patch_size: Size of patches (default 256)
        add_indices: If True, add spectral indices as extra channels
    """
    
    BANDS = ['B01', 'B02', 'B03', 'B04', 'B05', 'B06', 
             'B07', 'B08', 'B8A', 'B09', 'B11', 'B12']
    
    def __init__(
        self,
        data_root,
        split_file=None,
        bands=None,
        mode='train',
        binary=True,
        transform=None,
        patch_size=256,
        add_indices=False
    ):
        self.data_root = Path(data_root)
        self.mode = mode
        self.binary = binary
        self.patch_size = patch_size
        self.add_indices = add_indices
        self.bands = bands if bands else self.BANDS
        
        # Set up transforms
        if transform is not None:
            self.transform = transform
        else:
            self.transform = get_marida_transforms(mode, patch_size)
        
        # Load patch list from split file or scan directory
        self.patches = []
        if split_file and os.path.exists(split_file):
            self._load_from_split_file(split_file)
        else:
            self._scan_directory()
        
        print(f"MARIDA Dataset: Loaded {len(self.patches)} patches for {mode}")
    
    def _load_from_split_file(self, split_file):
        """Load patch IDs from split file."""
        with open(split_file, 'r') as f:
            patch_ids = [line.strip() for line in f if line.strip()]
        
        for patch_id in patch_ids:
            # Convert patch_id format: "1-12-19_48MYU_0" -> "S2_1-12-19_48MYU/S2_1-12-19_48MYU_0.tif"
            parts = patch_id.rsplit('_', 1)
            if len(parts) == 2:
                scene_id = f"S2_{parts[0]}"
                patch_num = parts[1]
                
                scene_dir = self.data_root / scene_id
                image_file = scene_dir / f"{scene_id}_{patch_num}.tif"
                label_file = scene_dir / f"{scene_id}_{patch_num}_cl.tif"
                
                if image_file.exists() and label_file.exists():
                    self.patches.append({
                        'id': patch_id,
                        'image': str(image_file),
                        'label': str(label_file)
                    })
    
    def _scan_directory(self):
        """Scan directory for all patches."""
        for scene_dir in self.data_root.iterdir():
            if scene_dir.is_dir() and scene_dir.name.startswith('S2_'):
                for tif_file in scene_dir.glob('*.tif'):
                    # Skip label and confidence files
                    if '_cl.tif' in tif_file.name or '_conf.tif' in tif_file.name:
                        continue
                    
                    # Find corresponding label file
                    label_file = tif_file.with_name(
                        tif_file.name.replace('.tif', '_cl.tif')
                    )
                    
                    if label_file.exists():
                        self.patches.append({
                            'id': tif_file.stem,
                            'image': str(tif_file),
                            'label': str(label_file)
                        })
    
    def __len__(self):
        return len(self.patches)
    
    def __getitem__(self, idx):
        patch_info = self.patches[idx]
        
        # Load multi-band image
        with rasterio.open(patch_info['image']) as src:
            image = src.read().astype(np.float32)
            # Normalize to [0, 1] - Sentinel-2 L2A reflectance
            image = image / 10000.0
            image = np.clip(image, 0, 1)
        
        # Load label
        with rasterio.open(patch_info['label']) as src:
            label = src.read(1).astype(np.int64)
        
        # Convert to binary if needed
        if self.binary:
            # 1 = debris (classes 1-4), 0 = non-debris
            binary_label = np.zeros_like(label)
            for cls in DEBRIS_CLASSES:
                binary_label[label == cls] = 1
            label = binary_label
        
        # Apply transforms (need to transpose for albumentations)
        # Albumentations expects (H, W, C) format
        image = np.transpose(image, (1, 2, 0))  # (C, H, W) -> (H, W, C)
        
        if self.transform:
            transformed = self.transform(image=image, mask=label)
            image = transformed['image']  # Returns (C, H, W) tensor
            label = transformed['mask']
        else:
            image = torch.from_numpy(image.transpose(2, 0, 1))
            label = torch.from_numpy(label)
        
        # Add spectral indices if requested
        if self.add_indices:
            from ..utils.spectral_indices import add_indices_to_bands
            image_np = image.numpy()
            image_with_indices = add_indices_to_bands(image_np)
            image = torch.from_numpy(image_with_indices)
        
        return {
            'image': image.float(),
            'label': label.long(),
            'id': patch_info['id']
        }


def create_marida_dataloaders(
    data_root,
    splits_dir,
    batch_size=8,
    num_workers=4,
    binary=True,
    patch_size=256,
    add_indices=False
):
    """
    Create train, validation, and test dataloaders for MARIDA.
    
    Args:
        data_root: Path to MARIDA/patches directory
        splits_dir: Path to MARIDA/splits directory
        batch_size: Batch size
        num_workers: Number of data loading workers
        binary: Binary classification mode
        patch_size: Patch size
        add_indices: Add spectral indices
    
    Returns:
        train_loader, val_loader, test_loader
    """
    from torch.utils.data import DataLoader
    
    splits_path = Path(splits_dir)
    
    train_dataset = MARIDADataset(
        data_root=data_root,
        split_file=splits_path / 'train_X.txt',
        mode='train',
        binary=binary,
        patch_size=patch_size,
        add_indices=add_indices
    )
    
    val_dataset = MARIDADataset(
        data_root=data_root,
        split_file=splits_path / 'val_X.txt',
        mode='val',
        binary=binary,
        patch_size=patch_size,
        add_indices=add_indices
    )
    
    test_dataset = MARIDADataset(
        data_root=data_root,
        split_file=splits_path / 'test_X.txt',
        mode='test',
        binary=binary,
        patch_size=patch_size,
        add_indices=add_indices
    )
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader, test_loader
