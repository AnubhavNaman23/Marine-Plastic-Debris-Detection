"""
Segmentation Model Factory using segmentation-models-pytorch (SMP)

Provides easy access to pretrained encoder-decoder architectures:
- UNet, UNet++, DeepLabV3+, FPN, PSPNet, LinkNet
- ResNet, EfficientNet, RegNet encoders (ImageNet pretrained)
"""

import torch
import torch.nn as nn
import segmentation_models_pytorch as smp


def get_segmentation_model(
    architecture='unetpp',
    encoder='resnet34',
    encoder_weights='imagenet',
    in_channels=12,
    classes=2,
    activation=None
):
    """
    Create a segmentation model using segmentation-models-pytorch.
    
    Args:
        architecture: Model architecture ('unet', 'unetpp', 'deeplabv3plus', 'fpn', 'pspnet')
        encoder: Encoder backbone ('resnet34', 'resnet50', 'efficientnet-b0', etc.)
        encoder_weights: Pretrained weights ('imagenet' or None)
        in_channels: Number of input channels (12 for Sentinel-2)
        classes: Number of output classes
        activation: Output activation (None, 'softmax', 'sigmoid')
    
    Returns:
        PyTorch model
    """
    architectures = {
        'unet': smp.Unet,
        'unetpp': smp.UnetPlusPlus,
        'deeplabv3plus': smp.DeepLabV3Plus,
        'fpn': smp.FPN,
        'pspnet': smp.PSPNet,
        'linknet': smp.Linknet,
        'manet': smp.MAnet,
        'pan': smp.PAN,
    }
    
    if architecture.lower() not in architectures:
        raise ValueError(f"Unknown architecture: {architecture}. "
                        f"Available: {list(architectures.keys())}")
    
    model_class = architectures[architecture.lower()]
    
    model = model_class(
        encoder_name=encoder,
        encoder_weights=encoder_weights,
        in_channels=in_channels,
        classes=classes,
        activation=activation
    )
    
    return model


class SegmentationModelWrapper(nn.Module):
    """
    Wrapper for SMP models with additional functionality.
    
    - Supports spectral indices as extra channels
    - Adds auxiliary classifier for deep supervision
    - Includes preprocessing for Sentinel-2 data
    """
    
    def __init__(
        self,
        architecture='unetpp',
        encoder='resnet34',
        encoder_weights='imagenet',
        in_channels=12,
        classes=2,
        add_indices=False,
        aux_classifier=False
    ):
        super().__init__()
        
        # Add 5 channels for spectral indices if requested
        actual_in_channels = in_channels + 5 if add_indices else in_channels
        
        self.base_model = get_segmentation_model(
            architecture=architecture,
            encoder=encoder,
            encoder_weights=encoder_weights,
            in_channels=actual_in_channels,
            classes=classes,
            activation=None
        )
        
        self.add_indices = add_indices
        self.aux_classifier = aux_classifier
        
        if aux_classifier:
            # Get encoder output channels
            encoder_channels = self.base_model.encoder.out_channels
            self.aux_head = nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Flatten(),
                nn.Linear(encoder_channels[-1], 256),
                nn.ReLU(),
                nn.Dropout(0.5),
                nn.Linear(256, classes)
            )
    
    def forward(self, x):
        # Add spectral indices if enabled
        if self.add_indices:
            from utils.spectral_indices import add_indices_to_bands
            batch_size = x.shape[0]
            x_np = x.cpu().numpy()
            x_with_indices = []
            for i in range(batch_size):
                xi = add_indices_to_bands(x_np[i])
                x_with_indices.append(xi)
            x = torch.from_numpy(np.stack(x_with_indices)).to(x.device)
        
        # Get segmentation output
        seg_out = self.base_model(x)
        
        if self.aux_classifier and self.training:
            # Get encoder features for auxiliary loss
            features = self.base_model.encoder(x)
            aux_out = self.aux_head(features[-1])
            return seg_out, aux_out
        
        return seg_out


def create_smp_model(config):
    """
    Create SMP model from configuration dictionary.
    
    Args:
        config: Dictionary with model configuration
            - architecture: str
            - encoder: str
            - encoder_weights: str or None
            - in_channels: int
            - classes: int
    
    Returns:
        Model instance
    """
    return get_segmentation_model(
        architecture=config.get('architecture', 'unetpp'),
        encoder=config.get('encoder', 'resnet34'),
        encoder_weights=config.get('encoder_weights', 'imagenet'),
        in_channels=config.get('in_channels', 12),
        classes=config.get('classes', 2)
    )


# Available encoders for reference
AVAILABLE_ENCODERS = [
    # ResNet
    'resnet18', 'resnet34', 'resnet50', 'resnet101', 'resnet152',
    # ResNeXt
    'resnext50_32x4d', 'resnext101_32x8d',
    # EfficientNet
    'efficientnet-b0', 'efficientnet-b1', 'efficientnet-b2', 'efficientnet-b3',
    'efficientnet-b4', 'efficientnet-b5', 'efficientnet-b6', 'efficientnet-b7',
    # DenseNet
    'densenet121', 'densenet169', 'densenet201',
    # VGG
    'vgg11_bn', 'vgg13_bn', 'vgg16_bn', 'vgg19_bn',
    # MobileNet
    'mobilenet_v2',
    # SE-Net
    'se_resnet50', 'se_resnet101', 'se_resnext50_32x4d',
    # RegNet
    'timm-regnetx_002', 'timm-regnetx_004', 'timm-regnetx_008',
    'timm-regnety_002', 'timm-regnety_004', 'timm-regnety_008',
]


# Test
if __name__ == "__main__":
    # Test various models
    print("Testing segmentation models...")
    
    x = torch.randn(2, 12, 256, 256)
    
    for arch in ['unet', 'unetpp', 'deeplabv3plus', 'fpn']:
        model = get_segmentation_model(
            architecture=arch,
            encoder='resnet34',
            encoder_weights=None,  # No pretrained for testing
            in_channels=12,
            classes=2
        )
        y = model(x)
        params = sum(p.numel() for p in model.parameters())
        print(f"{arch} with resnet34: output={y.shape}, params={params:,}")
