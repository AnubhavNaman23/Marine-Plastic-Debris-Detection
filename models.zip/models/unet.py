"""
UNet Architecture for Semantic Segmentation

Classic U-Net with configurable depth and features for marine debris detection.
Reference: Ronneberger et al. 2015 - "U-Net: Convolutional Networks for Biomedical Image Segmentation"
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class DoubleConv(nn.Module):
    """(Conv => BN => ReLU) * 2"""
    
    def __init__(self, in_channels, out_channels, mid_channels=None, dropout=0.0):
        super().__init__()
        if not mid_channels:
            mid_channels = out_channels
        
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout) if dropout > 0 else nn.Identity(),
            nn.Conv2d(mid_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout) if dropout > 0 else nn.Identity(),
        )
    
    def forward(self, x):
        return self.double_conv(x)


class Down(nn.Module):
    """Downscaling with maxpool then double conv"""
    
    def __init__(self, in_channels, out_channels, dropout=0.0):
        super().__init__()
        self.maxpool_conv = nn.Sequential(
            nn.MaxPool2d(2),
            DoubleConv(in_channels, out_channels, dropout=dropout)
        )
    
    def forward(self, x):
        return self.maxpool_conv(x)


class Up(nn.Module):
    """Upscaling then double conv"""
    
    def __init__(self, in_channels, out_channels, bilinear=True, dropout=0.0):
        super().__init__()
        
        if bilinear:
            self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
            self.conv = DoubleConv(in_channels, out_channels, in_channels // 2, dropout=dropout)
        else:
            self.up = nn.ConvTranspose2d(in_channels, in_channels // 2, kernel_size=2, stride=2)
            self.conv = DoubleConv(in_channels, out_channels, dropout=dropout)
    
    def forward(self, x1, x2):
        x1 = self.up(x1)
        
        # Pad if necessary
        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]
        x1 = F.pad(x1, [diffX // 2, diffX - diffX // 2,
                       diffY // 2, diffY - diffY // 2])
        
        # Concatenate
        x = torch.cat([x2, x1], dim=1)
        return self.conv(x)


class OutConv(nn.Module):
    """Final output convolution"""
    
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
    
    def forward(self, x):
        return self.conv(x)


class UNet(nn.Module):
    """
    UNet Architecture for Semantic Segmentation.
    
    Args:
        n_channels: Number of input channels (e.g., 12 for Sentinel-2)
        n_classes: Number of output classes (2 for binary)
        base_features: Number of features in first layer (doubled at each level)
        depth: Number of encoding/decoding levels
        bilinear: Use bilinear upsampling vs transposed convolutions
        dropout: Dropout rate for regularization
    """
    
    def __init__(
        self,
        n_channels=12,
        n_classes=2,
        base_features=64,
        depth=4,
        bilinear=True,
        dropout=0.1
    ):
        super().__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear
        self.depth = depth
        
        # Initial convolution
        self.inc = DoubleConv(n_channels, base_features, dropout=dropout)
        
        # Encoder (downsampling path)
        factor = 2 if bilinear else 1
        self.downs = nn.ModuleList()
        in_ch = base_features
        
        for i in range(depth):
            out_ch = min(base_features * (2 ** (i + 1)), 1024)  # Cap at 1024
            if i == depth - 1:
                out_ch = out_ch // factor
            self.downs.append(Down(in_ch, out_ch, dropout=dropout))
            in_ch = out_ch
        
        # Decoder (upsampling path)
        self.ups = nn.ModuleList()
        
        for i in range(depth - 1, -1, -1):
            in_ch = min(base_features * (2 ** (i + 1)), 1024)
            out_ch = base_features * (2 ** i) // factor if i > 0 else base_features
            self.ups.append(Up(in_ch, out_ch, bilinear, dropout=dropout))
        
        # Output
        self.outc = OutConv(base_features, n_classes)
    
    def forward(self, x):
        # Encoder
        x_enc = [self.inc(x)]
        
        for down in self.downs:
            x_enc.append(down(x_enc[-1]))
        
        # Decoder
        x = x_enc[-1]
        for i, up in enumerate(self.ups):
            x = up(x, x_enc[-(i + 2)])
        
        # Output
        logits = self.outc(x)
        return logits
    
    def predict(self, x):
        """Make predictions with softmax."""
        logits = self.forward(x)
        return F.softmax(logits, dim=1)


class UNetWithAttention(nn.Module):
    """
    UNet with Attention Gates for improved feature focusing.
    
    Attention gates help the model focus on relevant debris regions.
    """
    
    def __init__(
        self,
        n_channels=12,
        n_classes=2,
        base_features=64,
        bilinear=True,
        dropout=0.1
    ):
        super().__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear
        
        factor = 2 if bilinear else 1
        
        self.inc = DoubleConv(n_channels, base_features, dropout=dropout)
        self.down1 = Down(base_features, base_features * 2, dropout=dropout)
        self.down2 = Down(base_features * 2, base_features * 4, dropout=dropout)
        self.down3 = Down(base_features * 4, base_features * 8, dropout=dropout)
        self.down4 = Down(base_features * 8, base_features * 16 // factor, dropout=dropout)
        
        # Attention gates
        self.att4 = AttentionGate(base_features * 8, base_features * 16 // factor, base_features * 8)
        self.att3 = AttentionGate(base_features * 4, base_features * 8, base_features * 4)
        self.att2 = AttentionGate(base_features * 2, base_features * 4, base_features * 2)
        self.att1 = AttentionGate(base_features, base_features * 2, base_features)
        
        self.up1 = Up(base_features * 16, base_features * 8 // factor, bilinear, dropout=dropout)
        self.up2 = Up(base_features * 8, base_features * 4 // factor, bilinear, dropout=dropout)
        self.up3 = Up(base_features * 4, base_features * 2 // factor, bilinear, dropout=dropout)
        self.up4 = Up(base_features * 2, base_features, bilinear, dropout=dropout)
        
        self.outc = OutConv(base_features, n_classes)
    
    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        
        # Apply attention gates
        x4 = self.att4(x4, x5)
        x = self.up1(x5, x4)
        
        x3 = self.att3(x3, x)
        x = self.up2(x, x3)
        
        x2 = self.att2(x2, x)
        x = self.up3(x, x2)
        
        x1 = self.att1(x1, x)
        x = self.up4(x, x1)
        
        logits = self.outc(x)
        return logits


class AttentionGate(nn.Module):
    """Attention Gate for UNet."""
    
    def __init__(self, F_g, F_l, F_int):
        super().__init__()
        self.W_g = nn.Sequential(
            nn.Conv2d(F_g, F_int, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(F_int)
        )
        self.W_x = nn.Sequential(
            nn.Conv2d(F_l, F_int, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(F_int)
        )
        self.psi = nn.Sequential(
            nn.Conv2d(F_int, 1, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(1),
            nn.Sigmoid()
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, g, x):
        g1 = self.W_g(g)
        x1 = self.W_x(x)
        
        # Upsample g1 if needed
        if g1.shape[2:] != x1.shape[2:]:
            g1 = F.interpolate(g1, size=x1.shape[2:], mode='bilinear', align_corners=True)
        
        psi = self.relu(g1 + x1)
        psi = self.psi(psi)
        
        return x * psi


# Test
if __name__ == "__main__":
    # Test UNet
    model = UNet(n_channels=12, n_classes=2)
    x = torch.randn(2, 12, 256, 256)
    y = model(x)
    print(f"UNet output shape: {y.shape}")
    print(f"Total parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    # Test UNet with Attention
    model_att = UNetWithAttention(n_channels=12, n_classes=2)
    y_att = model_att(x)
    print(f"UNet+Attention output shape: {y_att.shape}")
    print(f"Total parameters: {sum(p.numel() for p in model_att.parameters()):,}")
