"""
Advanced Classification Models for Pixel-Level Marine Debris Detection

Models for classifying individual pixels based on spectral bands and indices:
1. Multi-Layer Perceptron (MLP)
2. 1D CNN for spectral sequences
3. Transformer Encoder
4. Attention-based Networks
5. Residual Networks
6. Ensemble Methods

These models work on tabular/1D spectral data (not images).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


# =============================================================================
# 1. Multi-Layer Perceptron (MLP) - Baseline
# =============================================================================

class MLP(nn.Module):
    """
    Multi-Layer Perceptron for spectral classification.
    
    Args:
        n_features: Number of input features (bands + indices)
        n_classes: Number of output classes
        hidden_dims: List of hidden layer dimensions
        dropout: Dropout rate
    """
    def __init__(self, n_features, n_classes, hidden_dims=[256, 128, 64], dropout=0.3):
        super().__init__()
        
        layers = []
        in_dim = n_features
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(in_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout)
            ])
            in_dim = hidden_dim
        
        layers.append(nn.Linear(in_dim, n_classes))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)


# =============================================================================
# 2. 1D Convolutional Neural Network
# =============================================================================

class SpectralCNN1D(nn.Module):
    """
    1D CNN treating spectral bands as a sequence.
    
    Captures local patterns in the spectral signature.
    """
    def __init__(self, n_features, n_classes, channels=[64, 128, 256], dropout=0.3):
        super().__init__()
        
        # Reshape input: (batch, features) -> (batch, 1, features)
        self.conv_layers = nn.ModuleList()
        in_channels = 1
        
        for out_channels in channels:
            self.conv_layers.append(nn.Sequential(
                nn.Conv1d(in_channels, out_channels, kernel_size=3, padding=1),
                nn.BatchNorm1d(out_channels),
                nn.ReLU(),
                nn.MaxPool1d(2) if n_features > 4 else nn.Identity(),
                nn.Dropout(dropout)
            ))
            in_channels = out_channels
            n_features = n_features // 2 if n_features > 4 else n_features
        
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(channels[-1], n_classes)
    
    def forward(self, x):
        # (batch, features) -> (batch, 1, features)
        x = x.unsqueeze(1)
        
        for conv in self.conv_layers:
            x = conv(x)
        
        x = self.global_pool(x).squeeze(-1)
        return self.fc(x)


class SpectralCNN2D(nn.Module):
    """
    2D CNN treating spectral features as a small "image".
    
    Reshapes features into a 2D grid for spatial pattern learning.
    """
    def __init__(self, n_features, n_classes, base_channels=32, dropout=0.3):
        super().__init__()
        
        # Calculate grid size (closest to square)
        self.h = int(math.sqrt(n_features))
        self.w = (n_features + self.h - 1) // self.h
        self.pad_size = self.h * self.w - n_features
        
        self.conv = nn.Sequential(
            nn.Conv2d(1, base_channels, 3, padding=1),
            nn.BatchNorm2d(base_channels),
            nn.ReLU(),
            nn.Conv2d(base_channels, base_channels * 2, 3, padding=1),
            nn.BatchNorm2d(base_channels * 2),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(2),
            nn.Flatten(),
            nn.Dropout(dropout)
        )
        
        self.fc = nn.Sequential(
            nn.Linear(base_channels * 2 * 4, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, n_classes)
        )
    
    def forward(self, x):
        batch_size = x.size(0)
        
        # Pad and reshape to 2D
        if self.pad_size > 0:
            x = F.pad(x, (0, self.pad_size))
        x = x.view(batch_size, 1, self.h, self.w)
        
        x = self.conv(x)
        return self.fc(x)


# =============================================================================
# 3. Transformer Encoder for Spectral Data
# =============================================================================

class PositionalEncoding(nn.Module):
    """Positional encoding for transformer."""
    def __init__(self, d_model, max_len=100):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(0))
    
    def forward(self, x):
        return x + self.pe[:, :x.size(1)]


class SpectralTransformer(nn.Module):
    """
    Transformer Encoder for spectral classification.
    
    Treats each spectral band/index as a token in a sequence.
    """
    def __init__(
        self,
        n_features,
        n_classes,
        d_model=64,
        n_heads=4,
        n_layers=3,
        dim_feedforward=256,
        dropout=0.1
    ):
        super().__init__()
        
        # Input embedding
        self.input_embed = nn.Linear(1, d_model)
        self.pos_encoding = PositionalEncoding(d_model, n_features)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        
        # Classification head
        self.cls_token = nn.Parameter(torch.randn(1, 1, d_model))
        self.classifier = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, n_classes)
        )
    
    def forward(self, x):
        batch_size = x.size(0)
        
        # (batch, features) -> (batch, features, 1) -> (batch, features, d_model)
        x = x.unsqueeze(-1)
        x = self.input_embed(x)
        x = self.pos_encoding(x)
        
        # Add CLS token
        cls_tokens = self.cls_token.expand(batch_size, -1, -1)
        x = torch.cat([cls_tokens, x], dim=1)
        
        # Transformer
        x = self.transformer(x)
        
        # Use CLS token for classification
        cls_output = x[:, 0]
        return self.classifier(cls_output)


# =============================================================================
# 4. Attention-Based Networks
# =============================================================================

class SelfAttention(nn.Module):
    """Self-attention layer."""
    def __init__(self, dim, heads=4, dropout=0.1):
        super().__init__()
        self.heads = heads
        self.scale = (dim // heads) ** -0.5
        
        self.qkv = nn.Linear(dim, dim * 3)
        self.proj = nn.Linear(dim, dim)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.heads, C // self.heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.dropout(attn)
        
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        return self.proj(x)


class AttentionClassifier(nn.Module):
    """
    Attention-based classifier with multi-head self-attention.
    """
    def __init__(self, n_features, n_classes, hidden_dim=128, n_heads=4, n_layers=2, dropout=0.2):
        super().__init__()
        
        # Input projection
        self.input_proj = nn.Sequential(
            nn.Linear(1, hidden_dim),
            nn.LayerNorm(hidden_dim)
        )
        
        # Attention layers
        self.attention_layers = nn.ModuleList([
            nn.Sequential(
                SelfAttention(hidden_dim, n_heads, dropout),
                nn.LayerNorm(hidden_dim),
                nn.Linear(hidden_dim, hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout)
            ) for _ in range(n_layers)
        ])
        
        # Global attention pooling
        self.attention_weights = nn.Linear(hidden_dim, 1)
        
        # Classifier
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, n_classes)
        )
    
    def forward(self, x):
        # (batch, features) -> (batch, features, 1) -> (batch, features, hidden)
        x = x.unsqueeze(-1)
        x = self.input_proj(x)
        
        # Apply attention layers
        for attn_layer in self.attention_layers:
            x = x + attn_layer(x)
        
        # Attention pooling
        weights = F.softmax(self.attention_weights(x), dim=1)
        x = (x * weights).sum(dim=1)
        
        return self.classifier(x)


class ChannelAttention(nn.Module):
    """Squeeze-and-Excitation style channel attention."""
    def __init__(self, channels, reduction=4):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction),
            nn.ReLU(),
            nn.Linear(channels // reduction, channels),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        weights = self.fc(x)
        return x * weights


class SENet(nn.Module):
    """
    Squeeze-and-Excitation Network for spectral features.
    """
    def __init__(self, n_features, n_classes, hidden_dims=[256, 128], dropout=0.3):
        super().__init__()
        
        layers = []
        in_dim = n_features
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(in_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                ChannelAttention(hidden_dim),
                nn.Dropout(dropout)
            ])
            in_dim = hidden_dim
        
        layers.append(nn.Linear(in_dim, n_classes))
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)


# =============================================================================
# 5. Residual Networks
# =============================================================================

class ResidualBlock(nn.Module):
    """Residual block for tabular data."""
    def __init__(self, dim, dropout=0.2):
        super().__init__()
        self.block = nn.Sequential(
            nn.Linear(dim, dim),
            nn.BatchNorm1d(dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.BatchNorm1d(dim)
        )
        self.relu = nn.ReLU()
    
    def forward(self, x):
        return self.relu(x + self.block(x))


class ResNet1D(nn.Module):
    """
    1D ResNet for spectral classification.
    """
    def __init__(self, n_features, n_classes, hidden_dim=256, n_blocks=4, dropout=0.2):
        super().__init__()
        
        self.input_proj = nn.Sequential(
            nn.Linear(n_features, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU()
        )
        
        self.res_blocks = nn.Sequential(*[
            ResidualBlock(hidden_dim, dropout) for _ in range(n_blocks)
        ])
        
        self.classifier = nn.Linear(hidden_dim, n_classes)
    
    def forward(self, x):
        x = self.input_proj(x)
        x = self.res_blocks(x)
        return self.classifier(x)


# =============================================================================
# 6. Hybrid Models
# =============================================================================

class CNNTransformerHybrid(nn.Module):
    """
    Hybrid model combining CNN and Transformer.
    
    CNN extracts local patterns, Transformer captures global relationships.
    """
    def __init__(self, n_features, n_classes, cnn_channels=64, d_model=128, n_heads=4, dropout=0.2):
        super().__init__()
        
        # CNN branch
        self.cnn = nn.Sequential(
            nn.Conv1d(1, cnn_channels, 3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Conv1d(cnn_channels, cnn_channels, 3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )
        
        # Transformer branch
        self.input_embed = nn.Linear(1, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dropout=dropout, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=2)
        self.trans_pool = nn.AdaptiveAvgPool1d(1)
        
        # Fusion and classification
        self.fusion = nn.Sequential(
            nn.Linear(cnn_channels + d_model, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, n_classes)
        )
    
    def forward(self, x):
        # CNN branch
        cnn_out = self.cnn(x.unsqueeze(1)).squeeze(-1)
        
        # Transformer branch
        trans_in = self.input_embed(x.unsqueeze(-1))
        trans_out = self.transformer(trans_in)
        trans_out = self.trans_pool(trans_out.transpose(1, 2)).squeeze(-1)
        
        # Fusion
        combined = torch.cat([cnn_out, trans_out], dim=1)
        return self.fusion(combined)


# =============================================================================
# 7. Ensemble Model
# =============================================================================

class EnsembleModel(nn.Module):
    """
    Ensemble of multiple models with learnable weights.
    """
    def __init__(self, models, n_classes, learnable_weights=True):
        super().__init__()
        self.models = nn.ModuleList(models)
        self.n_models = len(models)
        
        if learnable_weights:
            self.weights = nn.Parameter(torch.ones(self.n_models) / self.n_models)
        else:
            self.register_buffer('weights', torch.ones(self.n_models) / self.n_models)
    
    def forward(self, x):
        outputs = [model(x) for model in self.models]
        outputs = torch.stack(outputs, dim=0)  # (n_models, batch, classes)
        
        weights = F.softmax(self.weights, dim=0).view(-1, 1, 1)
        ensemble_out = (outputs * weights).sum(dim=0)
        
        return ensemble_out


# =============================================================================
# Model Factory
# =============================================================================

def get_classification_model(
    model_name,
    n_features,
    n_classes,
    **kwargs
):
    """
    Create a classification model by name.
    
    Args:
        model_name: One of 'mlp', 'cnn1d', 'cnn2d', 'transformer', 'attention',
                    'senet', 'resnet', 'hybrid', 'ensemble'
        n_features: Number of input features
        n_classes: Number of output classes
        **kwargs: Additional model-specific arguments
    
    Returns:
        Model instance
    """
    models = {
        'mlp': MLP,
        'cnn1d': SpectralCNN1D,
        'cnn2d': SpectralCNN2D,
        'transformer': SpectralTransformer,
        'attention': AttentionClassifier,
        'senet': SENet,
        'resnet': ResNet1D,
        'hybrid': CNNTransformerHybrid,
    }
    
    if model_name.lower() == 'ensemble':
        # Create ensemble of multiple models
        base_models = [
            MLP(n_features, n_classes),
            SpectralCNN1D(n_features, n_classes),
            SpectralTransformer(n_features, n_classes),
            AttentionClassifier(n_features, n_classes)
        ]
        return EnsembleModel(base_models, n_classes)
    
    if model_name.lower() not in models:
        raise ValueError(f"Unknown model: {model_name}. Available: {list(models.keys())}")
    
    return models[model_name.lower()](n_features, n_classes, **kwargs)


# Test models
if __name__ == "__main__":
    # Test all models
    n_features = 35  # 11 bands + 24 indices
    n_classes = 7
    batch_size = 32
    
    x = torch.randn(batch_size, n_features)
    
    model_names = ['mlp', 'cnn1d', 'cnn2d', 'transformer', 'attention', 'senet', 'resnet', 'hybrid', 'ensemble']
    
    for name in model_names:
        model = get_classification_model(name, n_features, n_classes)
        out = model(x)
        params = sum(p.numel() for p in model.parameters())
        print(f"{name:12} | Output: {out.shape} | Params: {params:,}")
