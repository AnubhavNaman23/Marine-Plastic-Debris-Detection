"""
Model architectures for Marine Debris Detection

Includes:
- Segmentation models (UNet, UNet++, etc.) for image-based detection
- Classification models (MLP, CNN, Transformer, Attention) for pixel-level classification
"""
from .unet import UNet
from .unetpp import UNetPlusPlus
from .segmentation_model import get_segmentation_model
from .classification_models import (
    MLP,
    SpectralCNN1D,
    SpectralCNN2D,
    SpectralTransformer,
    AttentionClassifier,
    SENet,
    ResNet1D,
    CNNTransformerHybrid,
    EnsembleModel,
    get_classification_model
)

__all__ = [
    # Segmentation models
    'UNet', 
    'UNetPlusPlus', 
    'get_segmentation_model',
    # Classification models
    'MLP',
    'SpectralCNN1D',
    'SpectralCNN2D',
    'SpectralTransformer',
    'AttentionClassifier',
    'SENet',
    'ResNet1D',
    'CNNTransformerHybrid',
    'EnsembleModel',
    'get_classification_model'
]
