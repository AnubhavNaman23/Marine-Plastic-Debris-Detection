"""
UNet++ (Nested UNet) Architecture

UNet++ improves upon UNet with dense skip connections for better 
gradient flow and feature propagation.

Reference: Zhou et al. 2018 - "UNet++: A Nested U-Net Architecture for Medical Image Segmentation"
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvBlock(nn.Module):
    """Double convolution block."""
    
    def __init__(self, in_channels, out_channels, dropout=0.0):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout) if dropout > 0 else nn.Identity(),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout) if dropout > 0 else nn.Identity(),
        )
    
    def forward(self, x):
        return self.conv(x)


class UNetPlusPlus(nn.Module):
    """
    UNet++ with nested skip connections.
    
    Architecture:
    - X0,0 -> X0,1 -> X0,2 -> X0,3 -> X0,4 (encoder)
            \\      \\      \\      \\
              X1,0 -> X1,1 -> X1,2 -> X1,3
                    \\      \\      \\
                      X2,0 -> X2,1 -> X2,2
                            \\      \\
                              X3,0 -> X3,1
                                    \\
                                      X4,0
    
    Args:
        n_channels: Number of input channels (12 for Sentinel-2)
        n_classes: Number of output classes
        features: List of features at each level [32, 64, 128, 256, 512]
        deep_supervision: Return intermediate outputs for auxiliary loss
        dropout: Dropout rate
    """
    
    def __init__(
        self,
        n_channels=12,
        n_classes=2,
        features=[32, 64, 128, 256, 512],
        deep_supervision=False,
        dropout=0.1
    ):
        super().__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.deep_supervision = deep_supervision
        
        f = features
        
        # Encoder
        self.conv0_0 = ConvBlock(n_channels, f[0], dropout)
        self.conv1_0 = ConvBlock(f[0], f[1], dropout)
        self.conv2_0 = ConvBlock(f[1], f[2], dropout)
        self.conv3_0 = ConvBlock(f[2], f[3], dropout)
        self.conv4_0 = ConvBlock(f[3], f[4], dropout)
        
        # Nested skip pathways
        self.conv0_1 = ConvBlock(f[0] + f[1], f[0], dropout)
        self.conv1_1 = ConvBlock(f[1] + f[2], f[1], dropout)
        self.conv2_1 = ConvBlock(f[2] + f[3], f[2], dropout)
        self.conv3_1 = ConvBlock(f[3] + f[4], f[3], dropout)
        
        self.conv0_2 = ConvBlock(f[0] * 2 + f[1], f[0], dropout)
        self.conv1_2 = ConvBlock(f[1] * 2 + f[2], f[1], dropout)
        self.conv2_2 = ConvBlock(f[2] * 2 + f[3], f[2], dropout)
        
        self.conv0_3 = ConvBlock(f[0] * 3 + f[1], f[0], dropout)
        self.conv1_3 = ConvBlock(f[1] * 3 + f[2], f[1], dropout)
        
        self.conv0_4 = ConvBlock(f[0] * 4 + f[1], f[0], dropout)
        
        # Pooling
        self.pool = nn.MaxPool2d(2, 2)
        
        # Upsampling
        self.up1_0 = nn.ConvTranspose2d(f[1], f[1], 2, stride=2)
        self.up2_0 = nn.ConvTranspose2d(f[2], f[2], 2, stride=2)
        self.up3_0 = nn.ConvTranspose2d(f[3], f[3], 2, stride=2)
        self.up4_0 = nn.ConvTranspose2d(f[4], f[4], 2, stride=2)
        
        self.up1_1 = nn.ConvTranspose2d(f[1], f[1], 2, stride=2)
        self.up2_1 = nn.ConvTranspose2d(f[2], f[2], 2, stride=2)
        self.up3_1 = nn.ConvTranspose2d(f[3], f[3], 2, stride=2)
        
        self.up1_2 = nn.ConvTranspose2d(f[1], f[1], 2, stride=2)
        self.up2_2 = nn.ConvTranspose2d(f[2], f[2], 2, stride=2)
        
        self.up1_3 = nn.ConvTranspose2d(f[1], f[1], 2, stride=2)
        
        # Output
        if deep_supervision:
            self.final1 = nn.Conv2d(f[0], n_classes, 1)
            self.final2 = nn.Conv2d(f[0], n_classes, 1)
            self.final3 = nn.Conv2d(f[0], n_classes, 1)
            self.final4 = nn.Conv2d(f[0], n_classes, 1)
        else:
            self.final = nn.Conv2d(f[0], n_classes, 1)
    
    def forward(self, x):
        # Encoder
        x0_0 = self.conv0_0(x)
        x1_0 = self.conv1_0(self.pool(x0_0))
        x0_1 = self.conv0_1(torch.cat([x0_0, self._upsample(self.up1_0(x1_0), x0_0)], 1))
        
        x2_0 = self.conv2_0(self.pool(x1_0))
        x1_1 = self.conv1_1(torch.cat([x1_0, self._upsample(self.up2_0(x2_0), x1_0)], 1))
        x0_2 = self.conv0_2(torch.cat([x0_0, x0_1, self._upsample(self.up1_1(x1_1), x0_0)], 1))
        
        x3_0 = self.conv3_0(self.pool(x2_0))
        x2_1 = self.conv2_1(torch.cat([x2_0, self._upsample(self.up3_0(x3_0), x2_0)], 1))
        x1_2 = self.conv1_2(torch.cat([x1_0, x1_1, self._upsample(self.up2_1(x2_1), x1_0)], 1))
        x0_3 = self.conv0_3(torch.cat([x0_0, x0_1, x0_2, self._upsample(self.up1_2(x1_2), x0_0)], 1))
        
        x4_0 = self.conv4_0(self.pool(x3_0))
        x3_1 = self.conv3_1(torch.cat([x3_0, self._upsample(self.up4_0(x4_0), x3_0)], 1))
        x2_2 = self.conv2_2(torch.cat([x2_0, x2_1, self._upsample(self.up3_1(x3_1), x2_0)], 1))
        x1_3 = self.conv1_3(torch.cat([x1_0, x1_1, x1_2, self._upsample(self.up2_2(x2_2), x1_0)], 1))
        x0_4 = self.conv0_4(torch.cat([x0_0, x0_1, x0_2, x0_3, self._upsample(self.up1_3(x1_3), x0_0)], 1))
        
        if self.deep_supervision:
            out1 = self.final1(x0_1)
            out2 = self.final2(x0_2)
            out3 = self.final3(x0_3)
            out4 = self.final4(x0_4)
            return [out1, out2, out3, out4]
        else:
            return self.final(x0_4)
    
    def _upsample(self, x, reference):
        """Upsample x to match reference size."""
        if x.shape[2:] != reference.shape[2:]:
            x = F.interpolate(x, size=reference.shape[2:], mode='bilinear', align_corners=True)
        return x
    
    def predict(self, x):
        """Make predictions with softmax."""
        if self.deep_supervision:
            outputs = self.forward(x)
            # Average all outputs
            out = torch.stack(outputs, dim=0).mean(dim=0)
            return F.softmax(out, dim=1)
        else:
            return F.softmax(self.forward(x), dim=1)


class UNetPlusPlusLite(nn.Module):
    """
    Lightweight UNet++ for faster training/inference.
    
    Uses fewer features and simplified architecture.
    """
    
    def __init__(
        self,
        n_channels=12,
        n_classes=2,
        base_features=32,
        dropout=0.1
    ):
        super().__init__()
        
        f = [base_features, base_features*2, base_features*4, base_features*8]
        
        # Encoder
        self.conv0_0 = ConvBlock(n_channels, f[0], dropout)
        self.conv1_0 = ConvBlock(f[0], f[1], dropout)
        self.conv2_0 = ConvBlock(f[1], f[2], dropout)
        self.conv3_0 = ConvBlock(f[2], f[3], dropout)
        
        # Nested paths
        self.conv0_1 = ConvBlock(f[0] + f[1], f[0], dropout)
        self.conv1_1 = ConvBlock(f[1] + f[2], f[1], dropout)
        self.conv2_1 = ConvBlock(f[2] + f[3], f[2], dropout)
        
        self.conv0_2 = ConvBlock(f[0]*2 + f[1], f[0], dropout)
        self.conv1_2 = ConvBlock(f[1]*2 + f[2], f[1], dropout)
        
        self.conv0_3 = ConvBlock(f[0]*3 + f[1], f[0], dropout)
        
        self.pool = nn.MaxPool2d(2, 2)
        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        
        self.final = nn.Conv2d(f[0], n_classes, 1)
    
    def forward(self, x):
        x0_0 = self.conv0_0(x)
        x1_0 = self.conv1_0(self.pool(x0_0))
        x0_1 = self.conv0_1(torch.cat([x0_0, self.up(x1_0)], 1))
        
        x2_0 = self.conv2_0(self.pool(x1_0))
        x1_1 = self.conv1_1(torch.cat([x1_0, self.up(x2_0)], 1))
        x0_2 = self.conv0_2(torch.cat([x0_0, x0_1, self.up(x1_1)], 1))
        
        x3_0 = self.conv3_0(self.pool(x2_0))
        x2_1 = self.conv2_1(torch.cat([x2_0, self.up(x3_0)], 1))
        x1_2 = self.conv1_2(torch.cat([x1_0, x1_1, self.up(x2_1)], 1))
        x0_3 = self.conv0_3(torch.cat([x0_0, x0_1, x0_2, self.up(x1_2)], 1))
        
        return self.final(x0_3)


# Test
if __name__ == "__main__":
    # Test UNet++
    model = UNetPlusPlus(n_channels=12, n_classes=2, deep_supervision=True)
    x = torch.randn(2, 12, 256, 256)
    outputs = model(x)
    print(f"UNet++ outputs: {[o.shape for o in outputs]}")
    print(f"Total parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    # Test lightweight version
    model_lite = UNetPlusPlusLite(n_channels=12, n_classes=2)
    y = model_lite(x)
    print(f"UNet++ Lite output: {y.shape}")
    print(f"Lite parameters: {sum(p.numel() for p in model_lite.parameters()):,}")
