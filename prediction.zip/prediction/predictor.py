"""
Prediction Module for Marine Debris Detection

Handles inference on new Sentinel-2 images with:
- Sliding window prediction for large images
- Ensemble predictions from multiple models
- Confidence calibration
- Post-processing for clean results
"""

import os
import numpy as np
import torch
import torch.nn.functional as F
import rasterio
from rasterio.windows import Window
from pathlib import Path
import matplotlib.pyplot as plt
from tqdm import tqdm


class DebrisPredictor:
    """
    Marine Debris Predictor for Sentinel-2 imagery.
    
    Args:
        model_path: Path to trained model checkpoint (.ckpt or .pt)
        model_class: Model class (if loading .pt file)
        device: Device for inference ('cuda' or 'cpu')
        patch_size: Size of patches for sliding window
        overlap: Overlap between patches (0.0 to 0.5)
        threshold: Probability threshold for debris detection
    """
    
    def __init__(
        self,
        model_path=None,
        model=None,
        device=None,
        patch_size=256,
        overlap=0.25,
        threshold=0.5
    ):
        self.patch_size = patch_size
        self.overlap = overlap
        self.threshold = threshold
        
        # Set device
        if device is None:
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        else:
            self.device = torch.device(device)
        
        # Load model
        if model is not None:
            self.model = model.to(self.device)
        elif model_path is not None:
            self.model = self._load_model(model_path)
        else:
            raise ValueError("Either model or model_path must be provided")
        
        self.model.eval()
        
        print(f"DebrisPredictor initialized on {self.device}")
    
    def _load_model(self, model_path):
        """Load model from checkpoint."""
        path = Path(model_path)
        
        if path.suffix == '.ckpt':
            # PyTorch Lightning checkpoint
            from training.lightning_module import MarineDebrisModule
            module = MarineDebrisModule.load_from_checkpoint(model_path)
            return module.model.to(self.device)
        elif path.suffix == '.pt' or path.suffix == '.pth':
            # PyTorch state dict
            state_dict = torch.load(model_path, map_location=self.device)
            
            # Try to infer model architecture from state dict
            # This is a simplified version - you might need to handle this differently
            from models import UNet
            model = UNet(n_channels=12, n_classes=2)
            model.load_state_dict(state_dict)
            return model.to(self.device)
        else:
            raise ValueError(f"Unknown model format: {path.suffix}")
    
    def predict(self, image_path, output_path=None, visualize=True):
        """
        Predict debris on a Sentinel-2 image.
        
        Args:
            image_path: Path to input image (GeoTIFF)
            output_path: Optional path to save prediction GeoTIFF
            visualize: Whether to show visualization
        
        Returns:
            Dictionary with:
                - 'probability': Debris probability map (H, W)
                - 'mask': Binary debris mask (H, W)
                - 'metrics': Detection metrics
        """
        # Load image
        with rasterio.open(image_path) as src:
            image = src.read().astype(np.float32)
            profile = src.profile.copy()
            height, width = src.height, src.width
        
        # Normalize
        image = image / 10000.0
        image = np.clip(image, 0, 1)
        
        # Predict with sliding window
        probability = self._sliding_window_predict(image)
        
        # Apply threshold
        mask = (probability > self.threshold).astype(np.uint8)
        
        # Calculate metrics
        debris_pixels = np.sum(mask)
        total_pixels = mask.size
        debris_percentage = (debris_pixels / total_pixels) * 100
        
        metrics = {
            'debris_pixels': int(debris_pixels),
            'total_pixels': int(total_pixels),
            'debris_percentage': float(debris_percentage),
            'max_probability': float(np.max(probability)),
            'mean_probability': float(np.mean(probability[mask > 0])) if debris_pixels > 0 else 0.0,
        }
        
        # Save output
        if output_path:
            self._save_prediction(output_path, probability, mask, profile)
        
        # Visualize
        if visualize:
            self._visualize(image_path, probability, mask, metrics)
        
        return {
            'probability': probability,
            'mask': mask,
            'metrics': metrics
        }
    
    def _sliding_window_predict(self, image):
        """Apply model with sliding window for large images."""
        channels, height, width = image.shape
        stride = int(self.patch_size * (1 - self.overlap))
        
        # Initialize outputs
        probability = np.zeros((height, width), dtype=np.float32)
        counts = np.zeros((height, width), dtype=np.float32)
        
        # Calculate window positions
        y_positions = list(range(0, height - self.patch_size + 1, stride))
        x_positions = list(range(0, width - self.patch_size + 1, stride))
        
        # Add final positions if needed
        if y_positions[-1] + self.patch_size < height:
            y_positions.append(height - self.patch_size)
        if x_positions[-1] + self.patch_size < width:
            x_positions.append(width - self.patch_size)
        
        # Process patches
        total_patches = len(y_positions) * len(x_positions)
        
        with torch.no_grad():
            for y in tqdm(y_positions, desc="Processing rows"):
                for x in x_positions:
                    # Extract patch
                    patch = image[:, y:y+self.patch_size, x:x+self.patch_size]
                    patch_tensor = torch.from_numpy(patch).unsqueeze(0).to(self.device)
                    
                    # Predict
                    logits = self.model(patch_tensor)
                    if isinstance(logits, list):
                        logits = logits[-1]
                    
                    probs = F.softmax(logits, dim=1)
                    debris_prob = probs[0, 1].cpu().numpy()
                    
                    # Accumulate with Gaussian weighting for smooth blending
                    weight = self._get_gaussian_weight(self.patch_size)
                    probability[y:y+self.patch_size, x:x+self.patch_size] += debris_prob * weight
                    counts[y:y+self.patch_size, x:x+self.patch_size] += weight
        
        # Average overlapping predictions
        probability = probability / (counts + 1e-8)
        
        return probability
    
    def _get_gaussian_weight(self, size):
        """Create Gaussian weight for smooth blending."""
        sigma = size / 4
        x = np.arange(size) - size // 2
        y = np.arange(size) - size // 2
        X, Y = np.meshgrid(x, y)
        weight = np.exp(-(X**2 + Y**2) / (2 * sigma**2))
        return weight
    
    def _save_prediction(self, output_path, probability, mask, profile):
        """Save prediction as GeoTIFF."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save probability map
        prob_profile = profile.copy()
        prob_profile.update(dtype='float32', count=1)
        
        prob_path = output_path.with_suffix('.probability.tif')
        with rasterio.open(prob_path, 'w', **prob_profile) as dst:
            dst.write(probability, 1)
        
        # Save binary mask
        mask_profile = profile.copy()
        mask_profile.update(dtype='uint8', count=1)
        
        mask_path = output_path.with_suffix('.mask.tif')
        with rasterio.open(mask_path, 'w', **mask_profile) as dst:
            dst.write(mask, 1)
        
        print(f"Saved: {prob_path}")
        print(f"Saved: {mask_path}")
    
    def _visualize(self, image_path, probability, mask, metrics):
        """Create visualization of results."""
        # Load RGB for visualization
        with rasterio.open(image_path) as src:
            # Try to get RGB bands (B04, B03, B02 for Sentinel-2)
            try:
                r = src.read(4)  # B04
                g = src.read(3)  # B03  
                b = src.read(2)  # B02
                rgb = np.stack([r, g, b], axis=-1)
                rgb = rgb / 10000.0
                rgb = np.clip(rgb, 0, 1)
                # Enhance contrast
                rgb = rgb ** 0.5
            except:
                rgb = src.read([1,2,3]).transpose(1, 2, 0)
                rgb = rgb / rgb.max()
        
        fig, axes = plt.subplots(1, 4, figsize=(20, 5))
        
        # RGB image
        axes[0].imshow(rgb)
        axes[0].set_title('RGB Composite')
        axes[0].axis('off')
        
        # Probability map
        im = axes[1].imshow(probability, cmap='RdYlGn_r', vmin=0, vmax=1)
        axes[1].set_title('Debris Probability')
        axes[1].axis('off')
        plt.colorbar(im, ax=axes[1], fraction=0.046)
        
        # Binary mask
        axes[2].imshow(mask, cmap='Reds', vmin=0, vmax=1)
        axes[2].set_title(f'Debris Mask (threshold={self.threshold})')
        axes[2].axis('off')
        
        # Overlay
        overlay = rgb.copy()
        overlay[mask > 0] = [1, 0, 0]  # Red for debris
        axes[3].imshow(overlay)
        axes[3].set_title(f'Overlay ({metrics["debris_percentage"]:.4f}% debris)')
        axes[3].axis('off')
        
        plt.tight_layout()
        plt.show()
        
        # Print metrics
        print("\n" + "="*50)
        print("DETECTION RESULTS")
        print("="*50)
        print(f"Debris pixels: {metrics['debris_pixels']:,}")
        print(f"Total pixels: {metrics['total_pixels']:,}")
        print(f"Debris coverage: {metrics['debris_percentage']:.4f}%")
        print(f"Max probability: {metrics['max_probability']:.4f}")
        print(f"Mean debris probability: {metrics['mean_probability']:.4f}")
        print("="*50)


def predict_image(image_path, model_path, output_path=None, threshold=0.5):
    """
    Quick function to predict debris on a single image.
    
    Args:
        image_path: Path to Sentinel-2 GeoTIFF
        model_path: Path to trained model
        output_path: Optional output path
        threshold: Detection threshold
    
    Returns:
        Prediction results dictionary
    """
    predictor = DebrisPredictor(
        model_path=model_path,
        threshold=threshold
    )
    return predictor.predict(image_path, output_path)


def batch_predict(image_dir, model_path, output_dir, threshold=0.5, pattern='*.tif'):
    """
    Batch predict debris on multiple images.
    
    Args:
        image_dir: Directory with input images
        model_path: Path to trained model
        output_dir: Output directory
        threshold: Detection threshold
        pattern: Glob pattern for input files
    
    Returns:
        List of prediction results
    """
    image_dir = Path(image_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    predictor = DebrisPredictor(
        model_path=model_path,
        threshold=threshold
    )
    
    results = []
    for image_path in image_dir.glob(pattern):
        print(f"\nProcessing: {image_path.name}")
        output_path = output_dir / image_path.name
        
        try:
            result = predictor.predict(
                str(image_path),
                str(output_path),
                visualize=False
            )
            result['file'] = image_path.name
            results.append(result)
        except Exception as e:
            print(f"Error processing {image_path.name}: {e}")
    
    return results
